package Domain;

import java.util.List;

public class Student {
		private String stuName;
		private int id;
		private boolean intelStu;
		private boolean graduate;
		private List<Course> courses;
		
		public Student(String stuName, int id, boolean intelStu, boolean graduate, List<Course> courses) {
			this.stuName = stuName;
			this.id = id;
			this.intelStu = intelStu;
			this.graduate = graduate;
			this.courses = courses;
		}
		
		public String getStuName() {
			return stuName;
		}
		public void setStuName(String stuName) {
			this.stuName = stuName;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public boolean isIntelStu() {
			return intelStu;
		}
		public void setIntelStu(boolean intelStu) {
			this.intelStu = intelStu;
		}
		public boolean isGraduate() {
			return graduate;
		}
		public void setGraduate(boolean graduate) {
			this.graduate = graduate;
		}
		public List<Course> getCourses() {
			return courses;
		}
		public void setCourses(List<Course> courses) {
			this.courses = courses;
		}
		
		
}
