package Service;

import java.util.List;

import Domain.Course;
import Domain.Student;
import Service.CheckoutService;
import Service.PaymentService;
import Service.TuitionCaculateService;

public class CheckoutPayment implements CheckoutService {
	
	private PaymentService paymentService;
	private TuitionCaculateService tuitionCaculateService;
	
	@Override
	public void checkout(Student student, List<Course> courses, String creditCardNum) {
		
		//Add courses to student and update the enrollment number
		//List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			//studentCourses.add(course);
			course.setStuEnrolled(course.getStuEnrolled()+1);
		}
		
		//Compute the tuition bill
		double amount = tuitionCaculateService.computeTutition(student, courses);
		
		//Process Payment
		paymentService.makePayment(student, amount, creditCardNum);
	}
	
	public void setPaymentService(PaymentService paymentService) {
		this.paymentService = paymentService;
	}
	
	public void setTuitionCaculateService(TuitionCaculateService tuitionCaculateService) {
		this.tuitionCaculateService = tuitionCaculateService;
	}
	
}
