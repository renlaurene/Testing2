package Service;

import java.util.List;

import Domain.Course;
import Domain.Student;

public interface TuitionCaculateService {
	
	public double computeTutition(Student student, List<Course> courses);
}


