package Service;

import Domain.Student;
import Service.PaymentService;

public class PayPalPayment implements PaymentService {

	@Override
	public void makePayment(Student student, double amount, String creditCardNum) {
		System.out.println("Using the PayPal credit card processor to process credit card number: " + creditCardNum
				+ "; for student: " + student.getStuName() + "; Payment of: " + amount);
		
	}
}