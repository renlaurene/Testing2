package Service;

import Domain.Student;

public interface PaymentService {
	
	public void makePayment(Student student, double amount, String creditCardNum);
}


