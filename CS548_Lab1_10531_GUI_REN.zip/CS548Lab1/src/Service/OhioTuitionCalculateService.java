package Service;

import java.util.List;

import Domain.Course;
import Domain.Student;
import Service.TuitionCaculateService;

public class OhioTuitionCaculateService implements TuitionCaculateService {
	
	@Override
	public double computeTutition(Student student, List<Course> courses) {
		int totalUnits = 0;
		double totalTuition = 0.0;
		
		//List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			//studentCourses.add(course);
			totalUnits = totalUnits + course.getNumberOfUnits();
			if (course.getDepartName().equals("Chemistry")) {
				totalTuition += 50;
			}
		}
		
		if( student.isGraduate() ) {
			totalTuition = totalUnits * 120;
		}else {
			totalTuition = totalUnits * 100;
		}
		
		
		if( student.isIntelStu()) {
			totalTuition = totalTuition * 1.1;
		}
		
		return totalTuition;
		
	}

}
