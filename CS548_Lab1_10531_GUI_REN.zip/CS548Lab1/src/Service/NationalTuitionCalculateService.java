package Service;

import java.util.List;

import Domain.Course;
import Domain.Student;
import Service.TuitionCaculateService;

public class NationalTuitionCaculateService implements TuitionCaculateService {
	
	@Override
	public double computeTutition(Student student, List<Course> courses) {
		double totalTuition;
		int totalUnits = 0;
		
		//List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			//studentCourses.add(course);
			totalUnits += course.getNumberOfUnits();
		}
		
		if( student.isIntelStu() ) {
			totalTuition = 500.0 * totalUnits;
		}else {
			totalTuition = 230.0 * totalUnits;
		}
		return totalTuition;
	}

}