package Service;

import java.util.List;

import Domain.Course;
import Domain.Student;

public interface CheckoutService {
	
	public void checkout(Student student, List<Course> courses, String creditCardNum);
}
